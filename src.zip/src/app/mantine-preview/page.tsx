"use client";

import {
  ActionIcon,
  Badge,
  Button,
  Card,
  Container,
  Group,
  Paper,
  Progress,
  Select,
  SimpleGrid,
  Stack,
  Table,
  Text,
  TextInput,
  Title,
  SegmentedControl,
  Divider,
} from "@mantine/core";
import { useState } from "react";

const bosses = [
  {
    name: "Ant Queen",
    type: "EPIC",
    lastKill: "2026-04-14 21:35",
    respawn: "2026-04-15 18:35",
    status: "Soon",
    progress: 82,
  },
  {
    name: "Core",
    type: "EPIC",
    lastKill: "2026-04-14 18:10",
    respawn: "2026-04-15 15:10",
    status: "Waiting",
    progress: 56,
  },
  {
    name: "Orfen",
    type: "UNIQUE",
    lastKill: "2026-04-15 00:20",
    respawn: "2026-04-15 20:20",
    status: "Tracked",
    progress: 71,
  },
  {
    name: "Baium",
    type: "QUEST",
    lastKill: "2026-04-13 23:00",
    respawn: "2026-04-15 23:00",
    status: "Today",
    progress: 93,
  },
];

function getTypeColor(type: string) {
  switch (type) {
    case "EPIC":
      return "red";
    case "UNIQUE":
      return "yellow";
    case "QUEST":
      return "blue";
    default:
      return "gray";
  }
}

function getStatusColor(status: string) {
  switch (status) {
    case "Soon":
      return "orange";
    case "Tracked":
      return "green";
    case "Today":
      return "violet";
    default:
      return "gray";
  }
}

export default function MantinePreviewPage() {
  const [mode, setMode] = useState("dashboard");

  const rows = bosses.map((boss) => (
    <Table.Tr key={boss.name}>
      <Table.Td>
        <Text fw={600}>{boss.name}</Text>
      </Table.Td>
      <Table.Td>
        <Badge color={getTypeColor(boss.type)} variant="light">
          {boss.type}
        </Badge>
      </Table.Td>
      <Table.Td>{boss.lastKill}</Table.Td>
      <Table.Td>{boss.respawn}</Table.Td>
      <Table.Td>
        <Badge color={getStatusColor(boss.status)} variant="light">
          {boss.status}
        </Badge>
      </Table.Td>
      <Table.Td miw={140}>
        <Progress value={boss.progress} size="sm" radius="xl" />
      </Table.Td>
      <Table.Td>
        <Group gap="xs">
          <Button size="xs" variant="light">
            Edit
          </Button>
          <Button size="xs" color="red" variant="light">
            Delete
          </Button>
        </Group>
      </Table.Td>
    </Table.Tr>
  ));

  return (
    <Container size="xl" py="xl">
      <Stack gap="xl">
        <Paper withBorder radius="md" p="md">
          <Group justify="space-between" align="center">
            <div>
              <Title order={2}>L2 Boss Tracker</Title>
              <Text c="dimmed" size="sm">
                Mantine preview page for redesign testing
              </Text>
            </div>

            <Group>
              <Button variant="subtle">Bosses</Button>
              <Button variant="subtle">Tracking</Button>
              <Button variant="subtle">Settings</Button>
              <Button>Add boss</Button>
            </Group>
          </Group>
        </Paper>

        <Group justify="space-between" align="end">
          <div>
            <Title order={3}>Design preview</Title>
            <Text c="dimmed" size="sm">
              Смотри, как Mantine ощущается на карточках, таблице и формах
            </Text>
          </div>

          <SegmentedControl
            value={mode}
            onChange={setMode}
            data={[
              { label: "Dashboard", value: "dashboard" },
              { label: "Compact", value: "compact" },
            ]}
          />
        </Group>

        <SimpleGrid cols={{ base: 1, sm: 2, lg: 4 }}>
          <Card withBorder radius="md" p="lg">
            <Text c="dimmed" size="sm">
              Total bosses
            </Text>
            <Title order={2}>124</Title>
            <Text size="sm" c="green">
              +6 this week
            </Text>
          </Card>

          <Card withBorder radius="md" p="lg">
            <Text c="dimmed" size="sm">
              Tracked now
            </Text>
            <Title order={2}>18</Title>
            <Text size="sm" c="dimmed">
              Active tracking entries
            </Text>
          </Card>

          <Card withBorder radius="md" p="lg">
            <Text c="dimmed" size="sm">
              Next respawn
            </Text>
            <Title order={2}>02:14:33</Title>
            <Text size="sm" c="orange">
              Ant Queen
            </Text>
          </Card>

          <Card withBorder radius="md" p="lg">
            <Text c="dimmed" size="sm">
              Epics today
            </Text>
            <Title order={2}>4</Title>
            <Text size="sm" c="violet">
              Baium, Core, AQ, Orfen
            </Text>
          </Card>
        </SimpleGrid>

        <SimpleGrid cols={{ base: 1, lg: 3 }} spacing="lg">
          <Card withBorder radius="md" p="lg">
            <Stack>
              <Title order={4}>Filters</Title>

              <TextInput label="Search boss" placeholder="Ant Queen" />

              <Select
                label="Boss type"
                placeholder="Select type"
                data={["EPIC", "UNIQUE", "QUEST", "NORMAL"]}
              />

              <Select
                label="Status"
                placeholder="Select status"
                data={["Tracked", "Soon", "Today", "Waiting"]}
              />

              <Group mt="sm">
                <Button>Apply</Button>
                <Button variant="default">Reset</Button>
              </Group>
            </Stack>
          </Card>

          <Card withBorder radius="md" p="lg">
            <Stack>
              <Title order={4}>Tracking settings</Title>

              <TextInput label="Default respawn (hours)" placeholder="24" />
              <TextInput label="Server name" placeholder="Antharas x1200" />
              <Select
                label="Notification mode"
                placeholder="Select mode"
                data={["Disabled", "Soon", "All respawns"]}
              />

              <Group mt="sm">
                <Button color="green">Save</Button>
                <Button variant="default">Cancel</Button>
              </Group>
            </Stack>
          </Card>

          <Card withBorder radius="md" p="lg">
            <Stack>
              <Title order={4}>Status legend</Title>

              <Group>
                <Badge color="red" variant="light">
                  EPIC
                </Badge>
                <Badge color="yellow" variant="light">
                  UNIQUE
                </Badge>
                <Badge color="blue" variant="light">
                  QUEST
                </Badge>
                <Badge color="gray" variant="light">
                  NORMAL
                </Badge>
              </Group>

              <Divider />

              <Group>
                <Badge color="green" variant="light">
                  Tracked
                </Badge>
                <Badge color="orange" variant="light">
                  Soon
                </Badge>
                <Badge color="violet" variant="light">
                  Today
                </Badge>
                <Badge color="gray" variant="light">
                  Waiting
                </Badge>
              </Group>

              <Text size="sm" c="dimmed">
                Этот блок нужен только чтобы быстро оценить визуальный стиль
                Mantine на живых элементах интерфейса.
              </Text>
            </Stack>
          </Card>
        </SimpleGrid>

        <Card withBorder radius="md" p="lg">
          <Stack>
            <Group justify="space-between">
              <div>
                <Title order={4}>Tracked bosses</Title>
                <Text c="dimmed" size="sm">
                  Preview table
                </Text>
              </div>

              <Group>
                <Button variant="default">Export</Button>
                <Button>Add entry</Button>
              </Group>
            </Group>

            <Table
              striped={mode === "compact"}
              highlightOnHover
              withTableBorder
              withColumnBorders={mode === "dashboard"}
              verticalSpacing="sm"
            >
              <Table.Thead>
                <Table.Tr>
                  <Table.Th>Boss</Table.Th>
                  <Table.Th>Type</Table.Th>
                  <Table.Th>Last kill</Table.Th>
                  <Table.Th>Respawn</Table.Th>
                  <Table.Th>Status</Table.Th>
                  <Table.Th>Progress</Table.Th>
                  <Table.Th>Actions</Table.Th>
                </Table.Tr>
              </Table.Thead>
              <Table.Tbody>{rows}</Table.Tbody>
            </Table>
          </Stack>
        </Card>
      </Stack>
    </Container>
  );
}